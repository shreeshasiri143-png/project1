from flask import Flask, render_template, request
import numpy as np
import joblib
import os

# Initialize Flask app
app = Flask(__name__)

# -------------------------------
# 🔹 Load Model (Correct Path Fix)
# -------------------------------
BASE_DIR = os.path.dirname(os.path.abspath(__file__))
MODEL_PATH = os.path.join(BASE_DIR, "model.pkl")

try:
    model = joblib.load(MODEL_PATH)
    print("✅ Model loaded successfully")
except Exception as e:
    print("❌ Error loading model:", e)
    model = None


# -------------------------------
# 🔹 Home Route
# -------------------------------
@app.route('/')
def home():
    return render_template('index.html')


# -------------------------------
# 🔹 Prediction Route
# -------------------------------
@app.route('/predict', methods=['POST'])
def predict():
    try:
        if model is None:
            return "❌ Model not found. Please check model.pkl file."

        # Get values from form
        input_features = request.form.to_dict()

        # Convert values to float
        features = []
        for key in input_features:
            value = float(input_features[key])
            features.append(value)

        # Convert to numpy array
        final_features = np.array([features])

        # Predict
        prediction = model.predict(final_features)

        # Output
        output = prediction[0]

        return render_template('index.html', prediction_text=f"🌱 Prediction Result: {output}")

    except Exception as e:
        return f"❌ Error occurred: {str(e)}"


# -------------------------------
# 🔹 Run Flask App
# -------------------------------
if __name__ == "__main__":
    app.run(debug=True)