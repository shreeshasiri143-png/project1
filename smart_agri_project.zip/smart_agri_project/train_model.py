import pandas as pd
from sklearn.ensemble import RandomForestClassifier
from sklearn.preprocessing import LabelEncoder
from sklearn.metrics import accuracy_score
import joblib

# Load dataset
data = pd.read_csv("dataset.csv")

# 🔥 CLEAN COLUMN NAMES
data.columns = data.columns.str.strip()

print("Columns:", data.columns)

# Encode categorical columns
le_soil = LabelEncoder()
le_crop = LabelEncoder()
le_fert = LabelEncoder()

data['Soil Type'] = le_soil.fit_transform(data['Soil Type'])
data['Crop Type'] = le_crop.fit_transform(data['Crop Type'])
data['Fertilizer Name'] = le_fert.fit_transform(data['Fertilizer Name'])

# Features (INPUT)
X = data[['Temparature', 'Humidity', 'Moisture',
          'Soil Type', 'Crop Type',
          'Nitrogen', 'Potassium', 'Phosphorous']]

# Target (OUTPUT)
y = data['Fertilizer Name']

# Train model
model = RandomForestClassifier(n_estimators=200)
model.fit(X, y)

# Accuracy (demo)
y_pred = model.predict(X)
accuracy = accuracy_score(y, y_pred)

print("✅ Accuracy:", accuracy * 100, "%")

# Save model + encoders
joblib.dump(model, "model.pkl")
joblib.dump(le_soil, "soil_encoder.pkl")
joblib.dump(le_crop, "crop_encoder.pkl")
joblib.dump(le_fert, "fert_encoder.pkl")

print("✅ Model & encoders saved")